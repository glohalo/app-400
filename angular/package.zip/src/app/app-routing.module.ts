import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { AppComponentImage } from './app.component.image';

const routes: Routes = [
  {
    path: "",
    redirectTo: "datos",
    pathMatch: "full"
  },
{
  path: "datos",
  component: AppComponent,
  //canActivate: [AuthGuard]
  //canActivate: [TimeGuard,AuthGuard]
  //canActivate: [AuthGuard]
},
{
  path: "verimg",
  component: AppComponentImage,
  //canActivate: [AuthGuard]
  //canActivate: [TimeGuard,AuthGuard]
  //canActivate: [AuthGuard]
}

]
@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
