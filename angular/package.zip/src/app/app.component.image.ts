import { Component, ViewEncapsulation, OnInit, Optional } from '@angular/core';
import { AppserviceService } from './appservice.service';
import Swal from 'sweetalert2'
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-app',
  templateUrl: './app.component.image.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponentImage implements OnInit {
  image: string = ""


  constructor() { }

  ngOnInit() {
    alert('consultando')
    this.image = sessionStorage.getItem('ruta')
  }





}