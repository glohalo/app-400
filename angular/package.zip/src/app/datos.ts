export class Datos{
    public id:number=0;
    public url:String="";
    public author:String="";

    constructor(id:number,url:string,author:string){}
}